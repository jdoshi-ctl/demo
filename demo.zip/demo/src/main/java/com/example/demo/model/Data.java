package com.example.demo.model;

public class Data {
	private String chassis;
	private String code;
	private String device_id;
	private String domain;
	private String hostname;
	private String location;
	private String role;
	private String site;
	private String timestamp;
	private String vendor;
	private String api_network;
	
	public Data() { }

	public String getChassis() {
		return chassis;
	}

	public void setChassis(String chassis) {
		this.chassis = chassis;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDevice_id() {
		return device_id;
	}

	public void setDevice_id(String device_id) {
		this.device_id = device_id;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getSite() {
		return site;
	}

	public void setSite(String site) {
		this.site = site;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public String getApi_network() {
		return api_network;
	}

	public void setApi_network(String api_network) {
		this.api_network = api_network;
	}

	@Override
	public String toString() {
		return "Data [chassis=" + chassis + ", code=" + code + ", device_id=" + device_id + ", domain=" + domain
				+ ", hostname=" + hostname + ", location=" + location + ", role=" + role + ", site=" + site
				+ ", timestamp=" + timestamp + ", vendor=" + vendor + ", api_network=" + api_network + "]";
	}
	
	
	
	
	/*
	 *   {
	   "chassis":"7750-SR-12",
	   "code":"14.0.R5",
	   "device_id":"10.159.3.52",
	   "domain":"GBLX",
	   "hostname":"ESP1.AKN4",
	   "location":"AKRON,OHIO",
	   "role":"ESP",
	   "site":"AKN4",
	   "timestamp":"2020-05-06 03:06:40.673782+00",
	   "vendor":"Alcatel",
	   "api_network":"green"
	 },
	 */
}
