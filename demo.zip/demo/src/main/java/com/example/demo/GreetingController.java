package com.example.demo;

import java.util.concurrent.atomic.AtomicLong;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class GreetingController {

	private static final String template = "Hello, %s!";
	private final AtomicLong counter = new AtomicLong();
	@Autowired
	private RestTemplate restTemplate;

	@GetMapping("/device")
	public ResponseEntity greeting(@RequestParam(value = "name", defaultValue = "World") String name) {
		ResponseEntity<String> resp = null;

		try {
			resp = restTemplate.getForEntity("https://devices.level3.com/v1/device?hostname="+name, String.class);
			System.out.println(resp);
			if (resp.getStatusCode() == HttpStatus.OK) {
				// It worked!
				// decode the body of the message
				String bodyInPlainString = resp.getBody();

			}

		} catch (Exception ex) {
			
			ex.printStackTrace();
		}
		// restTemplate=new RestTemplate();

		return resp;
	}
}
