package com.example.demo.model;

import java.util.List;


public class OpsDbResponse {
	private String identifier;
	private String host;
	private String uri;
	private String version;
	private String environment;
	private String owner;
	private Error error;
	private List<Data> data;
	private Long columns;
    private Long rows;
    private Long affected;
    private Long cached;
    private String runtime;
	
	public OpsDbResponse() { }

	
	public Long getColumns() {
		return columns;
	}


	public void setColumns(Long columns) {
		this.columns = columns;
	}


	public Long getRows() {
		return rows;
	}


	public void setRows(Long rows) {
		this.rows = rows;
	}


	public Long getAffected() {
		return affected;
	}


	public void setAffected(Long affected) {
		this.affected = affected;
	}


	public Long getCached() {
		return cached;
	}


	public void setCached(Long cached) {
		this.cached = cached;
	}


	public String getRuntime() {
		return runtime;
	}


	public void setRuntime(String runtime) {
		this.runtime = runtime;
	}


	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public Error getError() {
		return error;
	}

	public void setError(Error error) {
		this.error = error;
	}

	public List<Data> getData() {
		return data;
	}

	public void setData(List<Data> data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "OpsDbResponse [identifier=" + identifier + ", host=" + host + ", uri=" + uri + ", version=" + version
				+ ", environment=" + environment + ", owner=" + owner + ", error=" + error + ", data=" + data + "]";
	}
	

	
}
